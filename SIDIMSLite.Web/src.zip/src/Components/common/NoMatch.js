import React from 'react';
//import { NavLink } from "react-router-dom";

const NoMatch = ({ loading }) => {

    return (
        <div>
           No Content
        </div>
    );

};

export default NoMatch
