import React from 'react';

const IssueTracker = () => (

    <div>
        <article className="post">
            <h1>Getting Started With API </h1>

            <ul className="meta">
                <li>
                    <span>Created :</span> Feb, 04, 2016</li>
                <li>
                    <span>Last Updated:</span> April, 15, 2016</li>
            </ul>

            <div className="alert alert-info" role="alert">
                <span className="icon-info"></span>
                <p>
                    This documentation is always evolving. If you've not been here for a while, perhaps check out the This documentation is always
                    evolving.
                        </p>
            </div>

            <p>
                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by
                injected humour, or randomised words which don’t look even slightly believable.
                    </p>
            <p>
                If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle
                of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary,
                making this the first true generator on the Internet.
            </p>

            <img className="aligncenter" src="assets/images/connection.png" alt="" />

            <h2>Auth Services & Requirments</h2>
            <p>
                If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle
                of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary,
                making this the first true generator on the Internet.
                    </p>
            <blockquote>

                echo "Hello World"; echo "\n";

                    </blockquote>
            <h2>Final Step</h2>
            <p>
                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by
                injected humour, or randomised words which don’t look even slightly believable.
            </p>

        </article>
    </div>

    
)

export default IssueTracker