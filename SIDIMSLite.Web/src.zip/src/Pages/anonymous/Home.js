import React from 'react'

const Home = (props) => {
  return (
    <div>
      <h1>Welcome to the Tornadoes Website!</h1>
    </div>
  );
};

export default Home
