import React from 'react'

const Contact = () => (
  <div>
    <h1>Welcome to the Tornadoes Website!</h1>
  </div>
)

export default Contact