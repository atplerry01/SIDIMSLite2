export const myConfig = {
  importantData: "",
  apiUrl: "http://192.168.1.189:5001"
};
