export const myConfig = {
  importantData: "",
  apiUrl2: "http://62.173.38.182:5000",
  apiUrl1: "https://62.173.38.182:5001",
  apiUrl0: "https://localhost:5001",
  apiUrl: "https://sidims.secureidltd.com:5001"
};
